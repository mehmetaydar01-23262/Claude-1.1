import math
from datetime import date

import pandas as pd
import plotly.graph_objects as go
import requests
import streamlit as st

st.set_page_config(page_title="Field Shift", page_icon="🌱", layout="wide")

# ───────────────────────── THEME ─────────────────────────
GREEN, LEAF, WHEAT, BLUE, CLAY, INK = "#1B5E3B", "#4CAF50", "#E9B949", "#0B3D91", "#C8553D", "#14281D"

st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"] {{ font-family:'Inter',sans-serif; }}
#MainMenu, footer, header {{ visibility:hidden; }}
.stApp {{ background:#F6F4EC; }}
.block-container {{ padding-top:1.5rem; max-width:1200px; }}
.hero {{ background:linear-gradient(135deg,{GREEN} 0%,#0F3D2A 55%,{BLUE} 130%); border-radius:24px;
  padding:3rem; color:#fff; position:relative; overflow:hidden; margin-bottom:1.5rem; }}
.hero:after {{ content:""; position:absolute; right:-80px; top:-80px; width:340px; height:340px;
  background:radial-gradient(circle,{WHEAT}55,transparent 70%); border-radius:50%; }}
.badge {{ display:inline-block; background:rgba(255,255,255,.14); border:1px solid rgba(255,255,255,.25);
  padding:.3rem .9rem; border-radius:999px; font-size:.8rem; letter-spacing:.06em; margin-bottom:1rem; }}
.hero h1 {{ font-size:3rem; font-weight:800; margin:0 0 .4rem; color:#fff; line-height:1.1; }}
.hero h1 span {{ color:{WHEAT}; }}
.hero p {{ font-size:1.1rem; max-width:640px; color:#E3EFE7; margin:0; }}
.steps {{ display:grid; grid-template-columns:repeat(3,1fr); gap:1rem; margin-bottom:1rem; }}
.step {{ background:#fff; border:1px solid #E4E8E0; border-radius:18px; padding:1.2rem 1.3rem;
  box-shadow:0 2px 10px rgba(20,40,29,.05); }}
.step b {{ color:{GREEN}; }} .step .n {{ font-size:1.6rem; }}
.kpi {{ background:#fff; border:1px solid #E4E8E0; border-radius:18px; padding:1.1rem 1.3rem;
  box-shadow:0 2px 10px rgba(20,40,29,.05); border-top:4px solid var(--c); }}
.kpi .l {{ font-size:.78rem; color:#6B7A70; text-transform:uppercase; letter-spacing:.06em; }}
.kpi .v {{ font-size:1.9rem; font-weight:700; color:{INK}; margin-top:.15rem; }}
.kpi .u {{ font-size:.95rem; color:#6B7A70; font-weight:500; }}
.sec {{ margin:2.2rem 0 .8rem; }}
.sec:before {{ content:""; display:block; width:44px; height:4px; border-radius:4px; background:{WHEAT}; margin-bottom:.6rem; }}
.sec h2 {{ font-size:1.7rem; font-weight:700; color:{INK}; margin:0; }}
.sec p {{ color:#6B7A70; margin:.2rem 0 0; }}
.score {{ border-radius:22px; padding:1.6rem 2rem; display:flex; align-items:center; gap:1.5rem; background:var(--bg); }}
.score .num {{ font-size:3.6rem; font-weight:800; line-height:1; }}
section[data-testid="stSidebar"] {{ background:#0F2B1E; }}
section[data-testid="stSidebar"] * {{ color:#E8F1EB; }}
section[data-testid="stSidebar"] input, section[data-testid="stSidebar"] [data-baseweb="select"] * {{ color:{INK} !important; }}
section[data-testid="stSidebar"] .stButton > button {{ background:{WHEAT}; color:{INK} !important; font-weight:700; border:0; border-radius:12px; padding:.7rem; }}
</style>
""", unsafe_allow_html=True)


def section(title, sub=""):
    st.markdown(f'<div class="sec"><h2>{title}</h2><p>{sub}</p></div>', unsafe_allow_html=True)


def kpis(items):
    for col, (l, v, u, c) in zip(st.columns(len(items)), items):
        col.markdown(f'<div class="kpi" style="--c:{c}"><div class="l">{l}</div>'
                     f'<div class="v">{v} <span class="u">{u}</span></div></div>', unsafe_allow_html=True)


def score_card(score, text):
    bg = LEAF if score >= 75 else (WHEAT if score >= 50 else CLAY)
    fg = INK if 50 <= score < 75 else "#fff"
    st.markdown(f'<div class="score" style="--bg:{bg};color:{fg}"><div class="num">{score}'
                f'<span style="font-size:1.3rem">/100</span></div><div>{text}</div></div>', unsafe_allow_html=True)


def plot(traces, ytitle):
    fig = go.Figure(traces)
    fig.update_layout(height=330, margin=dict(l=10, r=10, t=10, b=10), yaxis_title=ytitle,
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font=dict(family="Inter", color=INK), legend=dict(orientation="h", y=1.12),
                      yaxis=dict(gridcolor="#E4E8E0"), xaxis=dict(showgrid=False))
    st.plotly_chart(fig, use_container_width=True)


def bar(s, ytitle, color=BLUE, x=None):
    plot([go.Bar(x=x or [m[:3] for m in s.index], y=s.values, marker_color=color, marker_cornerradius=6)], ytitle)


def line(s, ytitle, color=CLAY):
    plot([go.Scatter(x=[m[:3] for m in s.index], y=s.values, mode="lines+markers",
                     line=dict(color=color, width=3, shape="spline"), fill="tozeroy",
                     fillcolor="rgba(200,85,61,.12)")], ytitle)


def compare(df, ytitle):
    plot([go.Scatter(x=[m[:3] for m in df.index], y=df[c], name=c, mode="lines+markers",
                     line=dict(color=col, width=3, shape="spline"))
          for c, col in zip(df.columns, [BLUE, WHEAT])], ytitle)


# ───────────────────────── HERO ─────────────────────────
st.markdown("""
<div class="hero">
  <div class="badge">🛰️ NASA SPACE APPS CHALLENGE · FIELD SHIFT</div>
  <h1>Field <span>Shift</span></h1>
  <p>Adapting farms to a changing climate with NASA POWER satellite data. Understand your land,
  test climate scenarios, and make better planting decisions.</p>
</div>
<div class="steps">
  <div class="step"><div class="n">📍</div><b>1. Tell us your farm</b><br>Province, crop and soil.</div>
  <div class="step"><div class="n">🛰️</div><b>2. NASA analyzes it</b><br>Temperature, rain, ET₀ and crop water use.</div>
  <div class="step"><div class="n">🌾</div><b>3. Adapt</b><br>Suitability score, stress test and alternatives.</div>
</div>
""", unsafe_allow_html=True)

# ───────────────────────── DATA ─────────────────────────
def crop(kc, duration, month, temp, rain, family, alts):
    return dict(kc=kc, duration=duration, planting_month=month, temperature=temp,
                rainfall=rain, family=family, alternatives=alts)


CROPS = {
    "Wheat": crop([.35, .75, 1.15, .45], 8, 10, [8, 22], [250, 650], "Cereal", ["Chickpea", "Lentil", "Sunflower"]),
    "Barley": crop([.35, .75, 1.15, .45], 7, 10, [5, 22], [200, 550], "Cereal", ["Chickpea", "Lentil", "Sunflower"]),
    "Corn": crop([.40, .80, 1.15, .70], 5, 4, [18, 30], [400, 800], "Cereal", ["Soybean", "Wheat", "Chickpea"]),
    "Chickpea": crop([.40, .75, 1.00, .35], 4, 3, [10, 25], [200, 500], "Legume", ["Wheat", "Barley", "Sunflower"]),
    "Lentil": crop([.45, .75, 1.10, .50], 5, 11, [8, 23], [200, 500], "Legume", ["Wheat", "Barley", "Sunflower"]),
    "Soybean": crop([.35, .75, 1.10, .60], 5, 5, [18, 30], [400, 800], "Legume", ["Wheat", "Barley", "Sunflower"]),
    "Sunflower": crop([.35, .75, 1.15, .55], 5, 4, [15, 28], [300, 700], "Oilseed", ["Wheat", "Barley", "Chickpea"]),
    "Cotton": crop([.45, .75, 1.15, .75], 6, 4, [20, 32], [500, 1000], "Industrial crop", ["Wheat", "Chickpea", "Soybean"]),
}
MONTHS = ["January", "February", "March", "April", "May", "June", "July",
          "August", "September", "October", "November", "December"]
MONTH_NAMES = {i + 1: m for i, m in enumerate(MONTHS)}


@st.cache_data(ttl=86400)
def load_provinces():
    url = ("https://raw.githubusercontent.com/open-admin-data/"
           "turkey-administrative-divisions/master/data/all-province.json")
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    return {p["name"]["local"]: {"latitude": float(p["geo"]["lat"]), "longitude": float(p["geo"]["lon"])}
            for p in r.json()}


@st.cache_data(ttl=3600)
def get_nasa_data(lat, lon, start, end):
    cols = ["T2M", "T2M_MAX", "T2M_MIN", "PRECTOTCORR", "RH2M", "WS2M", "ALLSKY_SFC_SW_DWN", "PS"]
    r = requests.get("https://power.larc.nasa.gov/api/temporal/daily/point", timeout=90, params={
        "parameters": ",".join(cols), "community": "AG", "longitude": lon, "latitude": lat,
        "start": start, "end": end, "format": "JSON", "time-standard": "LST"})
    r.raise_for_status()
    df = pd.DataFrame(r.json()["properties"]["parameter"])
    df.index = pd.to_datetime(df.index, format="%Y%m%d")
    df = df.sort_index().replace(-999, float("nan")).dropna(subset=cols)
    if df.empty:
        raise ValueError("No usable NASA climate records were returned.")
    return df


def calculate_et0(df, latitude):
    phi = math.radians(latitude)

    def day(ts, row):
        t, tx, tn = row["T2M"], row["T2M_MAX"], row["T2M_MIN"]
        rh, u2, rs, p = row["RH2M"], row["WS2M"], row["ALLSKY_SFC_SW_DWN"], row["PS"]
        if min(t, tx, tn) <= -273 or rs < 0 or p <= 0:
            return float("nan")
        j = ts.dayofyear
        dr = 1 + 0.033 * math.cos(2 * math.pi * j / 365)
        dec = 0.409 * math.sin(2 * math.pi * j / 365 - 1.39)
        ws = math.acos(max(-1, min(1, -math.tan(phi) * math.tan(dec))))
        ra = (24 * 60 / math.pi) * 0.0820 * dr * (
            ws * math.sin(phi) * math.sin(dec) + math.cos(phi) * math.cos(dec) * math.sin(ws))
        es = (0.6108 * math.exp(17.27 * tx / (tx + 237.3)) + 0.6108 * math.exp(17.27 * tn / (tn + 237.3))) / 2
        ea = es * rh / 100
        delta = 4098 * (0.6108 * math.exp(17.27 * t / (t + 237.3))) / ((t + 237.3) ** 2)
        gamma = 0.000665 * p
        rso = 0.75 * ra
        if rso <= 0:
            return 0.0
        ratio = min(max(rs / rso, 0), 1)
        rnl = (4.903e-9 * (((tx + 273.16) ** 4 + (tn + 273.16) ** 4) / 2)
               * (0.34 - 0.14 * math.sqrt(max(ea, 0))) * (1.35 * ratio - 0.35))
        rn = 0.77 * rs - rnl
        et0 = (0.408 * delta * rn + gamma * (900 / (t + 273)) * u2 * (es - ea)) / (delta + gamma * (1 + 0.34 * u2))
        return max(0, et0)

    out = df.copy()
    out["ET0"] = [day(ts, row) for ts, row in out.iterrows()]
    out = out.dropna(subset=["ET0"])
    if out.empty:
        raise ValueError("Reference evapotranspiration could not be calculated.")
    return out


def calculate_kc(name, planting_month, ts):
    info = CROPS[name]
    k, dur = info["kc"], info["duration"]
    diff = (ts.month - planting_month) % 12
    if diff >= dur:
        return 0.0
    if dur <= 1:
        return k[2]
    p = diff / max(dur - 1, 1)
    if p < 0.20:
        return k[0]
    if p < 0.40:
        return k[0] + (k[1] - k[0]) * ((p - 0.20) / 0.20)
    if p < 0.75:
        return k[2]
    return k[2] + (k[3] - k[2]) * ((p - 0.75) / 0.25)


def analyze_crop_water(df, name, planting_month):
    r = df.copy()
    r["Kc"] = [calculate_kc(name, planting_month, ts) for ts in r.index]
    r["ETc"] = r["ET0"] * r["Kc"]
    r["Estimated_Effective_Rainfall"] = r["PRECTOTCORR"] * 0.80
    r["Water_Balance"] = r["ETc"] - r["Estimated_Effective_Rainfall"]
    r["Water_Deficit_Indicator"] = r["Water_Balance"].clip(lower=0)
    r["Month"] = [MONTH_NAMES[ts.month] for ts in r.index]
    monthly = r.groupby("Month").agg({
        "T2M": "mean", "T2M_MAX": "max", "T2M_MIN": "min", "PRECTOTCORR": "sum", "RH2M": "mean",
        "WS2M": "mean", "ET0": "sum", "ETc": "sum", "Estimated_Effective_Rainfall": "sum",
        "Water_Deficit_Indicator": "sum"})
    return r, monthly.reindex(MONTHS).fillna(0)


def calculate_suitability(name, monthly, planting_month, dtemp=0, drain=0):
    info = CROPS[name]
    season = monthly.iloc[[(planting_month + i - 1) % 12 for i in range(info["duration"])]]
    temp = season["T2M"].mean() + dtemp
    rain = season["PRECTOTCORR"].sum() * (1 + drain / 100)
    tmin, tmax = info["temperature"]
    rmin, rmax = info["rainfall"]

    if tmin <= temp <= tmax:
        ts = 100
    else:
        ts = max(0, 100 - (tmin - temp if temp < tmin else temp - tmax) * 8)
    if rmin <= rain <= rmax:
        rs = 100
    elif rain < rmin:
        rs = max(0, 100 - (rmin - rain) * 0.15)
    else:
        rs = max(0, 100 - (rain - rmax) * 0.10)

    deficit, etc = season["Water_Deficit_Indicator"].sum(), season["ETc"].sum()
    ws = max(0, 100 - (min(deficit / etc, 1) if etc > 0 else 0) * 100)
    return {"score": round(ts * 0.4 + rs * 0.3 + ws * 0.3), "temperature": round(ts), "rainfall": round(rs),
            "water": round(ws), "season_temperature": temp, "season_rainfall": rain, "season_deficit": deficit}


def calculate_alternatives(name, monthly):
    rows = [{"Crop": c, "Preliminary Score": calculate_suitability(c, monthly, CROPS[c]["planting_month"])["score"],
             "Crop Family": CROPS[c]["family"]} for c in CROPS[name]["alternatives"]]
    return pd.DataFrame(rows).sort_values("Preliminary Score", ascending=False)


# ───────────────────────── SIDEBAR ─────────────────────────
st.sidebar.header("🌾 Farm Profile")
try:
    provinces = load_provinces()
except Exception as e:
    st.error(f"Could not load province data: {e}")
    st.stop()

province = st.sidebar.selectbox("Select your province", sorted(provinces.keys()))
lat, lon = provinces[province]["latitude"], provinces[province]["longitude"]
if st.sidebar.checkbox("Use my actual farm coordinates"):
    lat = st.sidebar.number_input("Farm latitude", -90.0, 90.0, float(lat), format="%.5f")
    lon = st.sidebar.number_input("Farm longitude", -180.0, 180.0, float(lon), format="%.5f")
st.sidebar.caption(f"Coordinates: {lat:.4f}, {lon:.4f}")

selected_crop = st.sidebar.selectbox("Select your crop", list(CROPS.keys()))
planting_month = st.sidebar.selectbox("Planting month", list(range(1, 13)),
                                      index=CROPS[selected_crop]["planting_month"] - 1,
                                      format_func=lambda m: MONTH_NAMES[m])
soil_type = st.sidebar.selectbox("Soil type", ["Clay", "Sandy", "Loamy", "Silty"])
water_access = st.sidebar.selectbox("Water availability", ["High", "Medium", "Low"])
priority = st.sidebar.selectbox("Your agricultural priority", ["Water conservation", "Soil health", "Crop diversity"])

st.sidebar.divider()
st.sidebar.subheader("🌡️ Climate Stress Test")
dtemp = st.sidebar.selectbox("Hypothetical temperature change", [0, 1, 1.5, 2, 3], format_func=lambda v: f"+{v} °C")
drain = st.sidebar.selectbox("Hypothetical rainfall change", [0, -10, -20, -30, 10], format_func=lambda v: f"{v:+}%")
st.sidebar.caption("Hypothetical stress-test assumptions, not NASA climate projections.")

if st.sidebar.button("🌍 Analyze My Farm", use_container_width=True):
    st.session_state["analyzed"] = True

st.sidebar.divider()
for c in ["Climate data: NASA POWER", "Evapotranspiration: FAO-56 Penman-Monteith",
          "Crop coefficients: general reference inputs (prototype)", "Province coordinates: Open Admin Data"]:
    st.sidebar.caption(c)

# ───────────────────────── ANALYSIS ─────────────────────────
if st.session_state.get("analyzed"):
    with st.spinner("Retrieving NASA data and analyzing climate conditions..."):
        try:
            year = date.today().year - 1
            raw = get_nasa_data(lat, lon, f"{year}0101", f"{year}1231")
            df = calculate_et0(raw, lat)
            result, monthly = analyze_crop_water(df, selected_crop, planting_month)
            suit = calculate_suitability(selected_crop, monthly, planting_month)
            stress = calculate_suitability(selected_crop, monthly, planting_month, dtemp, drain)
            alts = calculate_alternatives(selected_crop, monthly)
        except Exception as e:
            st.error(f"An error occurred during analysis: {e}")
            st.info("Check your internet connection, NASA API access and selected coordinates.")
            st.stop()

    st.success(f"NASA climate data analyzed for {province} ({year}). Historical observations, not forecasts.")

    section("Climate Overview", f"{province} · {year} NASA POWER daily observations")
    kpis([("Avg Temperature", f"{df['T2M'].mean():.1f}", "°C", CLAY),
          ("Total Rainfall", f"{df['PRECTOTCORR'].sum():.0f}", "mm", BLUE),
          ("Relative Humidity", f"{df['RH2M'].mean():.0f}", "%", LEAF),
          ("Reference ET0", f"{df['ET0'].sum():.0f}", "mm", WHEAT)])

    section("Monthly Climate Analysis")
    c1, c2, c3 = st.columns(3)
    with c1:
        st.subheader("Temperature")
        line(monthly["T2M"], "°C")
    with c2:
        st.subheader("Rainfall")
        bar(monthly["PRECTOTCORR"], "mm")
    with c3:
        st.subheader("Reference water demand")
        bar(monthly["ET0"], "ET0 (mm)", WHEAT)

    section("Crop-Specific Water Analysis", f"Selected crop: {selected_crop}")
    total_etc, total_rain = result["ETc"].sum(), result["PRECTOTCORR"].sum()
    total_def = result["Water_Deficit_Indicator"].sum()
    kpis([("Crop Water Use", f"{total_etc:.0f}", "mm", BLUE),
          ("Total Rainfall", f"{total_rain:.0f}", "mm", LEAF),
          ("Rainfall Deficit Indicator", f"{total_def:.0f}", "mm", CLAY)])
    st.caption("ETc = ET0 × Kc. Effective rainfall is estimated as 80% of total rainfall. This is not an actual "
               "irrigation requirement; soil storage, runoff, drainage and irrigation are not included.")
    a, b = st.columns(2)
    with a:
        st.subheader("Monthly crop water use")
        bar(monthly["ETc"], "ETc (mm)")
    with b:
        st.subheader("Rainfall vs. crop water use")
        compare(monthly[["PRECTOTCORR", "ETc"]].rename(columns={"PRECTOTCORR": "Rainfall", "ETc": "Crop Water Use"}), "mm")

    section("Crop Suitability Assessment")
    s = suit["score"]
    msg = ("Reference ranges indicate generally favorable climate conditions." if s >= 75 else
           "Some climate conditions may create risks. Review local agricultural data." if s >= 50 else
           "Reference ranges indicate potential climate mismatches.")
    score_card(s, msg)
    st.write("")
    k1, k2 = st.columns([1, 1])
    with k1:
        bar(pd.Series([suit["temperature"], suit["rainfall"], suit["water"]]), "Score",
            LEAF, x=["Temperature", "Rainfall", "Water Balance"])
    with k2:
        st.write(f"- Average seasonal temperature: **{suit['season_temperature']:.1f} °C**")
        st.write(f"- Seasonal rainfall: **{suit['season_rainfall']:.0f} mm**")
        st.write(f"- Seasonal deficit indicator: **{suit['season_deficit']:.0f} mm**")
    st.caption("Experimental screening indicator based on broad reference ranges. It excludes soil pH, salinity, "
               "variety, disease, frost, altitude and local planting calendars. Not a sole basis for decisions.")

    section("Farmer Action Plan", "Actions to consider based on your farm profile and the climate data")
    if total_def > 100:
        st.warning("The rainfall deficit indicator is high. Monitor soil moisture and review your irrigation schedule.")
    elif total_def > 0:
        st.info("Rainfall may not fully meet crop water use. Verify irrigation needs with soil-moisture measurements.")
    else:
        st.success("No rainfall deficit indicated by this simplified calculation. Keep monitoring soil moisture.")

    water_tips = {"Low": "**Limited water:** consider drip irrigation, mulching and better irrigation scheduling.",
                  "Medium": "**Moderate water:** adjust irrigation to growth stages and soil moisture.",
                  "High": "**High water availability:** keep water use efficient and monitor consumption."}
    soil_tips = {"Clay": "**Clay soil:** monitor drainage; avoid heavy field work when wet.",
                 "Sandy": "**Sandy soil:** lower water retention; monitor moisture and add organic matter.",
                 "Loamy": "**Loamy soil:** maintain organic matter and healthy soil structure.",
                 "Silty": "**Silty soil:** monitor erosion and drainage, especially after heavy rain."}
    prio_tips = {"Water conservation": "Priority: water conservation. Drip irrigation, mulching and better timing.",
                 "Soil health": "Priority: soil health. Soil testing, organic matter and crop rotation.",
                 "Crop diversity": "Priority: crop diversity. Research alternative crops, local calendars and markets."}
    st.write(water_tips[water_access])
    st.write(soil_tips[soil_type])
    st.write(prio_tips[priority])

    section("Alternative Crops and Rotation Ideas")
    st.dataframe(alts, use_container_width=True, hide_index=True)
    st.info("A reliable rotation plan must consider crop families, disease cycles, nutrients, water needs and local "
            "calendars. This list is not a confirmed planting recommendation.")

    section("Climate Change Stress Test", f"Assumptions: temperature +{dtemp} °C, rainfall {drain:+}%")
    m1, m2 = st.columns(2)
    m1.metric("Current Conditions", f"{suit['score']}/100")
    m2.metric("Stress Test Result", f"{stress['score']}/100", delta=stress["score"] - suit["score"])
    st.caption("Hypothetical stress test, not a NASA climate projection or forecast.")

    section("Monthly Climate Data")
    st.dataframe(monthly.rename(columns={
        "T2M": "Avg Temp (°C)", "T2M_MAX": "Max Temp (°C)", "T2M_MIN": "Min Temp (°C)",
        "PRECTOTCORR": "Rainfall (mm)", "RH2M": "Humidity (%)", "WS2M": "Wind (m/s)", "ET0": "ET0 (mm)",
        "ETc": "ETc (mm)", "Estimated_Effective_Rainfall": "Eff. Rainfall (mm)",
        "Water_Deficit_Indicator": "Deficit (mm)"}).round(2), use_container_width=True)
    st.download_button("⬇️ Download Analysis as CSV", result.to_csv().encode("utf-8-sig"),
                       "field_shift_analysis.csv", "text/csv")
    with st.expander("View Daily NASA Data"):
        st.dataframe(result.round(3), use_container_width=True)
else:
    st.info("👈 Select your farm profile in the sidebar and click **Analyze My Farm** to start.")

st.divider()
st.caption("Field Shift is a research and decision-support prototype built for NASA Space Apps. "
           "Results do not replace professional agricultural advice or local soil testing.")
